# Marketing_II
Códigos en python de las clases.
